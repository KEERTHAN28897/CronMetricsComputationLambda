import fetch from 'node-fetch'
var express = require('express');
var app = express();
var fs = require("fs");

app.get('/', (request, response) => response.send(getBalanceJson('43114', '0x6AE65a7033a84bb36778fEA6607A25a0d6c8EE50')));
app.listen(3000, () => console.log('Listening on port 3000'));

const getBalanceJson = async (chain_id, address) => {
    //hardcoding for now.
    const response = await fetch('https://api.covalenthq.com/v1/' + chain_id + '/address/' + address + '/balances_v2/?quote-currency=USD&format=JSON&nft=false&no-nft-fetch=false&key=ckey_67a864f2a08941a9a5a88f32f1d')
    const responseJson = await response.json();
    return responseJson;
}