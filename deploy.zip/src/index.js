import fetch from 'node-fetch'

exports.handler = async (event) => {
  
    // TODO implement
    console.log(event)
    const chain_id = event['queryStringParameters']['coin'];
    const address = event['queryStringParameters']['wallet'];
    console.log('coin: ', chain_id);
    console.log('wallet: ', address);
    
        //hardcoding for now.
    const apiResponse = await fetch('https://api.covalenthq.com/v1/' + chain_id + '/address/' + address + '/balances_v2/?quote-currency=USD&format=JSON&nft=false&no-nft-fetch=false&key=ckey_67a864f2a08941a9a5a88f32f1d')
    const responseJson = await apiResponse.json();
    console.log(responseJson);
    console.log(responseJson['data']['items'])

    
    
    const response = {
        statusCode: 200,
        body: responseJson,
    };
    
    
    
    return response;
};
